# PLF110 CTN Patch + Daemon KernelSU 模块

这是为 OnePlus PLF110 / OP60F9L1（Android 16、MT6989、arm64-v8a）制作的完整 KernelSU 模块。

模块包含两部分：

* `ctb_name_patch.ko`：kprobe 型内核模块，为当前内核创建 `/proc/game_opt/task_boost/critical_task_name`。
* `plf110_ctnd`：用户态 daemon，读取 COSA 游戏配置并把关键线程写入 `rt_info` 和 `critical_task_name`。

`ctb_name_patch.ko` 已针对 `6.1.157-android14-11-o-gc2dad16af736` 编译，`vermagic` 与设备一致。安装后在 KernelSU 管理器中重启设备，开机时 `service.sh` 会先加载 KO，再启动 daemon。日志位于：

```text
/data/adb/modules/plf110_ctnd/plf110_ctnd.log
```

`start.sh` 会自动给 daemon 补上执行权限，以兼容部分 KernelSU 安装器不保留可执行位的行为。

卸载时先停止 daemon，再卸载 `ctb_name_patch`。

## 安全说明

内核模块不会修改 `oplus_bsp_game_opt` 的只读数据页，也不写它的 `critical_task` 指针数组。它在 `get_critical_task_state()` 入口处用 kprobe 覆盖匹配线程的返回值，避免旧版 `set_memory_rw/ro` 路径触发的内核 Oops。

本模块不会在安装时立即 `insmod`，也不会修改 `game_pid` 或 `es4g/critical_task`。每次内核更新后仍须用匹配源码重新编译 `.ko`。

